# HarborFlow Operations – Final Course Project

This package keeps EVERY requirement from the assignment while using the same basic implementation style as the supplied SOA-Product/SOA-Shopping practical.

Applications:
- HarborFlow-Eureka: 8761
- HarborFlow-Gateway: 8080
- HarborFlow-Carrier: 9092
- HarborFlow-Container: 9093
- HarborFlow-Yard: 9094
- HarborFlow-Gate: 9095

Technologies: Java 17, Maven, Spring Boot 4.1.0, Spring Web, JPA, MySQL, RestTemplate, Eureka, Spring Cloud Gateway, Spring Cloud LoadBalancer, JWT.

MySQL:
Create database `klu`; use root/admin as in the classroom practical.

Run:
1. MySQL
2. Eureka
3. Carrier, Container, Yard, Gate
4. Gateway

JWT:
POST http://localhost:8080/auth/login?username=admin&password=admin
Copy the returned token and use:
Authorization: Bearer <token>

Gateway routes:
 /carrier/** -> Carrier
 /container/** -> Container
 /yard/** -> Yard
 /gate/** -> Gate

Examples:
POST http://localhost:8080/container/insert
{
 "containerId":101,
 "containerNumber":"HF001",
 "carrierId":1,
 "status":"REGISTERED",
 "yardSlotId":0
}

POST http://localhost:8080/gate/checkin
{
 "gateId":1,
 "containerId":101,
 "vehicleNumber":"AP01AB1234",
 "operation":"CHECK_IN",
 "status":"NEW"
}

POST http://localhost:8080/yard/insert
{
 "slotId":1,
 "slotCode":"A-01",
 "containerId":0,
 "status":"AVAILABLE"
}

PUT http://localhost:8080/container/place/101/1
PUT http://localhost:8080/yard/loading/1
PUT http://localhost:8080/yard/unloading/1
PUT http://localhost:8080/yard/release/1

Note: The internal service calls use localhost ports to remain close to the SOA-Product/SOA-Shopping RestTemplate practical. Eureka + Gateway provide discovery/routing for client requests. Do not add technologies beyond the assignment without your instructor's approval.


Dependency note: Spring Boot 4.1.0 is paired with Spring Cloud 2025.1.2 in this package.
